
      real*8          dm
      integer            n,ma,mct,iel,nel,pstyp,eltyp,elty2,elty3
      common /eldata/ dm,n,ma,mct,iel,nel,pstyp,eltyp,elty2,elty3
