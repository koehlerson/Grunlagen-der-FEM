
      real*8          rlnew,timold,ds0,alfa0,c0,cs01,cs02,r,det,det0,xn
      common /arcler/ rlnew,timold,ds0,alfa0,c0,cs01,cs02,r,det,det0,xn
