
      real*8          psmx,psmn,xpsx,   xpsn
      common /psdat1/ psmx,psmn,xpsx(3),xpsn(3)
