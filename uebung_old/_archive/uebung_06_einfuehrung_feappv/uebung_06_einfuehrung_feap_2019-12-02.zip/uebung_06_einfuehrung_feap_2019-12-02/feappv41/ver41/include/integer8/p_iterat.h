
      integer*8  pu,prsd                        ! int8
