
      real*8          ang
      common /aceang/ ang(2)
