
      integer*8       nh1,nh2,nh3,ht1,ht2,ht3          !int8
      common /hdata/  nh1,nh2,nh3,ht1,ht2,ht3
