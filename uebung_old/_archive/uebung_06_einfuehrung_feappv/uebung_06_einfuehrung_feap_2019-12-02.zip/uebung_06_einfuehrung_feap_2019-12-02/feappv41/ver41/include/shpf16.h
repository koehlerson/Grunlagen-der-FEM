
      real*8          shp,       shp1,       shp2
      common /shpf16/ shp(3,8,9),shp1(3,4,9),shp2(3,4,9)
