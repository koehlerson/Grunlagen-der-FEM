
      real*8          dtn,dtold,steps
      logical                            fstep
      common /tdato/  dtn,dtold,steps(4),fstep(4)
