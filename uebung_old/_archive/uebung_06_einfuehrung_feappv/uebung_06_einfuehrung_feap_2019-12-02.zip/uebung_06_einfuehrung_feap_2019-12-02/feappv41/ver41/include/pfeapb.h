
      integer         numpn, numtn, numpeq, numteq, nar, nac, vneq
      common /pfeapb/ numpn, numtn, numpeq, numteq, nar, nac, vneq

      integer         nsbk,  mmode
      common /pfeapb/ nsbk,  mmode

      logical         pfeap_on, pfeap_blk, pfeap_view, pfeap_gnod
      common /pfeapb/ pfeap_on, pfeap_blk, pfeap_view, pfeap_gnod

      logical         pfeap_tang, pfeap_dstr, pfeap_glob, pfeap_bcin
      common /pfeapb/ pfeap_tang, pfeap_dstr, pfeap_glob, pfeap_bcin
