
      real*8           yy
      common /yield3f/ yy(9)
