
      integer          pl(10)                                   ! int8
