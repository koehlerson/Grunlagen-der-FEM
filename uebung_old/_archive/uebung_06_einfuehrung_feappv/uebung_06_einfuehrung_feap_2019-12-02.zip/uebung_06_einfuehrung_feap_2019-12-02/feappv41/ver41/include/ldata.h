
      integer         l,lv,lvs,   lve   ,li,lis,   lie
      common /ldata/  l,lv,lvs(9),lve(9),li,lis(9),lie(9)
