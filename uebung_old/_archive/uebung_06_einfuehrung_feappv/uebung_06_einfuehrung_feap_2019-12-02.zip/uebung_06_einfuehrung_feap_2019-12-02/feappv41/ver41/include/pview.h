
      real*8          cs,zview
      integer                  iview
      logical                        lview
      common /pview/  cs,zview,iview,lview
