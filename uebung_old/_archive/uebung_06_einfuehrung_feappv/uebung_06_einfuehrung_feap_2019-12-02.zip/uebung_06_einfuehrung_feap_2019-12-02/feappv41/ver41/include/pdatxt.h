
      real*8          dtext,xsyc
      integer                       jx1,jy1
      common /pdatxt/ dtext,xsyc(3),jx1,jy1
