
      integer         nio,neo,mao
      common /cblktr/ nio,neo,mao
