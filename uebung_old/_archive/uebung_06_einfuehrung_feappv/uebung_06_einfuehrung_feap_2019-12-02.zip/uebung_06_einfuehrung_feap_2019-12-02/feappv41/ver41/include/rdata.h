
      real*8          tol,rnmax,shift
      logical                         linear,shflg
      common /rdata/  tol,rnmax,shift,linear,shflg
