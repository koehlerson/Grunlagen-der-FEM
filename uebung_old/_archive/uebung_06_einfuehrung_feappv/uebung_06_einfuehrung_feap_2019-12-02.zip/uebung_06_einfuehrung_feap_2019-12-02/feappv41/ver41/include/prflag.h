
      logical         chflg,dyncon,fops,hadd,idenf,nmfl,trifl,floop
      common /prflag/ chflg,dyncon,fops,hadd,idenf,nmfl,trifl,floop(2)
