
      integer         numg,neqg
      common /eqslv/  numg,neqg
