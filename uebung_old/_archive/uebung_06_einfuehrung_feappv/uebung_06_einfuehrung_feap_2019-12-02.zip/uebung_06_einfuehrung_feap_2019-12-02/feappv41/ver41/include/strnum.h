
      integer         istv, iste, istp, istc
      common /strnum/ istv, iste, istp, istc
