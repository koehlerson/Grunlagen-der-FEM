
       integer          nmbody, neqmf, modbod
       real*8                                      ar     ,br
       common /modreg/  nmbody, neqmf, modbod(20), ar(3,3),br(3)
