
      logical          flgpl
      common /plast3f/ flgpl
