
      integer         processor
      common /setups/ processor

      logical         solver
      common /setups/ solver
