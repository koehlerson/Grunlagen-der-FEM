
      real*8          aengy,aold
      logical                    rfl
      common /endata/ aengy,aold,rfl
