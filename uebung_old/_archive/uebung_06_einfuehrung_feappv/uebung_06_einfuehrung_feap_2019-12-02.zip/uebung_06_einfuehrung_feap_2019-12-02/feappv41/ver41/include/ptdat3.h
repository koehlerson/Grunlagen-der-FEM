
      integer         ivpl,       iapl,       nvplts,naplts
      common /ptdat3/ ivpl(2,200),iapl(2,200),nvplts,naplts
