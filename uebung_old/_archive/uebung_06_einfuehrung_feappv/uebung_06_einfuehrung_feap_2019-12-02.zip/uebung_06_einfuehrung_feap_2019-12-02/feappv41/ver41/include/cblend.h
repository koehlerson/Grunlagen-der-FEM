
      integer         numsn,numsd,numfc,numbd,mxilr
      common /cblend/ numsn,numsd,numfc,numbd,mxilr
