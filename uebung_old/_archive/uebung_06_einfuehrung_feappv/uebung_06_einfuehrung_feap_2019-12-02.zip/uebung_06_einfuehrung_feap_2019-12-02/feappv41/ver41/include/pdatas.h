
      integer         isymm     ,iquad
      common /pdatas/ isymm(3,2),iquad(2,2,2)
