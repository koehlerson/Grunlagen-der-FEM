
      integer        ndd,nie,nud
      common /cdat1/ ndd,nie,nud
