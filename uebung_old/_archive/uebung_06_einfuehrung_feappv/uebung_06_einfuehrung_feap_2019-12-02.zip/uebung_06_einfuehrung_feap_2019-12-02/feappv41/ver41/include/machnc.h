
      real*8          epmac
      common /machnc/ epmac
