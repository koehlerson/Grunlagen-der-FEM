
      integer         starnd, starel
      common /dstars/ starnd, starel
