
      real*8          tpl
      integer                  itpl,       ntplts
      common /ptdat9/ tpl(200),itpl(2,200),ntplts
