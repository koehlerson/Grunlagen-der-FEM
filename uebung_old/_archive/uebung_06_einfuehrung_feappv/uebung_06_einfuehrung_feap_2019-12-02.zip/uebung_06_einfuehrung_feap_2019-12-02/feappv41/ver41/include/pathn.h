
      character       file*44,fau*12,fal*12
      common /pathn/  file(4),fau   ,fal
