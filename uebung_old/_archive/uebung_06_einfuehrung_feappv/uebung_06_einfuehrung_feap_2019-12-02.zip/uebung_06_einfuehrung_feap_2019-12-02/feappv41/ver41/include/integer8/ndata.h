
      integer*8       na,nal,nau                    ! int8
      common /ndata/  na,nal,nau

      integer*8       nc                            ! int8
      common /ndata/  nc

      integer*8       nl,nm                         ! int8
      common /ndata/  nl,nm

      integer*8       nx,nxu,nul                    ! int8
      common /ndata/  nx,nxu,nul

      integer         nv,nw,nxl                     ! int4
      common /ndata/  nv,nw,nxl
