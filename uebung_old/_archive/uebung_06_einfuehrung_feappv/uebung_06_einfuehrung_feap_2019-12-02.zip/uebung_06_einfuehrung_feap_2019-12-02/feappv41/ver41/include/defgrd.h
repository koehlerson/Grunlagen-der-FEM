
      real*8          f         ,df       ,finv       ,detf
      common /defgrd/ f(9,4,125),df(9,125),finv(9,125),detf(4,125)

      real*8          egreen   , ealmansi   , ebig   , esml
      common /defgrd/ egreen(6), ealmansi(6), ebig(6), esml(6)

      real*8          gradt       ,tg
      common /defgrd/ gradt(3,125),tg(125)

