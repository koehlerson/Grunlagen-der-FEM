
      integer         numnp,numel,nummat,nen,neq,ipr, netyp
      common /cdata/  numnp,numel,nummat,nen,neq,ipr, netyp
