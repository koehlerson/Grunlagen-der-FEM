
      integer         js     ,nn,nl1,nl2,nnn
      common /idata1/ js(999),nn,nl1,nl2,nnn
