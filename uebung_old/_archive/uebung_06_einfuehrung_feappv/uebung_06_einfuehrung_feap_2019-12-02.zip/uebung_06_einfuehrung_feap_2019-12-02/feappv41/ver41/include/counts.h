
      integer         nstep,niter,naugm, titer,taugm, iaugm, iform
      common /counts/ nstep,niter,naugm, titer,taugm, iaugm, iform
