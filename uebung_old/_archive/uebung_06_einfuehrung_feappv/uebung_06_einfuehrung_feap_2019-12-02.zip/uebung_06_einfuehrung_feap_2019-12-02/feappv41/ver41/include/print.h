
      logical         prt,prth,prnt,pfl,fopn
      common /print/  prt,prth,prnt,pfl,fopn
