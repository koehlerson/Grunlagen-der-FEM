
      real*8          scale,scaleg,s0,   dx,   sx,   fact
      common /pdata1/ scale,scaleg,s0(2),dx(2),sx(2),fact
