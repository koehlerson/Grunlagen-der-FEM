
      character       reafi*15,let*2
      common /corfil/ reafi   ,let
