
      integer         ia      ,ir      ,ea      ,er
      common /mdata/  ia(2,50),ir(2,50),ea(2,50),er(2,50)
