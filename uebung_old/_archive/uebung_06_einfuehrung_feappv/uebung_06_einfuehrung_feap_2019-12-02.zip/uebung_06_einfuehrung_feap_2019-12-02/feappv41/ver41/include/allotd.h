  
      integer         ilist       ,llist,ndict,ipoint     ,iprec
      common /allotd/ ilist(2,600),llist,ndict,ipoint(201),iprec(200)

      integer         dlist     ,  mmax, ddict     ,pdict
      common /allotd/ dlist(200),  mmax, ddict(200),pdict(200)
