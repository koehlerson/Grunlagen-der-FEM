
      logical         prompt,defalt,pscolr,psrevs
      common /prmptd/ prompt,defalt,pscolr,psrevs
