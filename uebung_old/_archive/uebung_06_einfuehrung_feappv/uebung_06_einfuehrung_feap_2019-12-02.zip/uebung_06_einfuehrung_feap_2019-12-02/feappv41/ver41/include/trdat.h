
      real*8          omega
      integer               mzad,mzal,mzdr,mdi,mdc
      logical                                      zflg
      common /trdat/  omega,mzad,mzal,mzdr,mdi,mdc,zflg
