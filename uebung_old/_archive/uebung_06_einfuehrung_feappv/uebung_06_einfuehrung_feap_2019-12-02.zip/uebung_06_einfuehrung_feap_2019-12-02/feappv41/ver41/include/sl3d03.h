
      real*8          rn0,    rt1,    rt2,    rd1,    rd2
      common /sl3d03/ rn0(24),rt1(24),rt2(24),rd1(24),rd2(24)

      real*8          rn1b,    rn2b
      common /sl3d03/ rn1b(24),rn2b(24)
