
      logical         surfl,boufl,disfl,forfl,angfl,reafl,intfl,sidfl
      common /corset/ surfl,boufl,disfl,forfl,angfl,reafl,intfl,sidfl

      logical         cprfl,damfl,masfl,stifl,basfl,anglefl,eulerfl
      common /corset/ cprfl,damfl,masfl,stifl,basfl,anglefl,eulerfl

      logical         triadfl
      common /corset/ triadfl

      logical         lfrfl, oldfl, tiefl, tief
      common /corset/ lfrfl, oldfl, tiefl, tief
