
      real*8          xt,xtol
      integer                 nxt
      common /xtout/  xt,xtol,nxt
