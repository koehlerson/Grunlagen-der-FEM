
      character      uct*4,utx(2)*15
      common /umac1/ uct  ,utx

      integer        urest,unumnd,unumel,unurnd
      common /umac2/ urest,unumnd,unumel,unurnd

      character      umshc*4  ,umanc*4  ,umacc*4  ,upltc*4
      common /umac3/ umshc(12),umanc(12),umacc(20),upltc(12)

      logical        ucount
      common /umac4/ ucount
