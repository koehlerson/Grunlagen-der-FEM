
      real*4          xp,     yp
      integer                         ipan,istruc
      common /pdatap/ xp(200),yp(200),ipan,istruc
