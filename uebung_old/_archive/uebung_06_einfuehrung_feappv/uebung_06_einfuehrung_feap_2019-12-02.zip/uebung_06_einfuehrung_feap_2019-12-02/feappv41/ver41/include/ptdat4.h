
      real*8          cpl
      integer                  icpl,       ncplts
      common /ptdat4/ cpl(200),icpl(2,200),ncplts
