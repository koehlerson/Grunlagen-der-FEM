
      real*8          xln
      real*8          rots       ,rvel       ,racc       ,thkl
      integer                                                     rotyp
      common /erotas/ xln(9,9,4),
     &                rots(3,9,2),rvel(3,9,2),racc(3,9,2),thkl(9),rotyp
