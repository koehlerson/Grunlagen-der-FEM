
      integer         iop,ios,ird,iwd,icl,lun
      common /iodata/ iop,ios,ird,iwd,icl,lun
