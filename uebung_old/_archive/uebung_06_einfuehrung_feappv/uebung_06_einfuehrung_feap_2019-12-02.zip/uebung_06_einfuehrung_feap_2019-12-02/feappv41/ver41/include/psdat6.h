
      integer         xll,yll,xur,yur
      real*8                          pscal
      common /psdat6/ xll,yll,xur,yur,pscal
