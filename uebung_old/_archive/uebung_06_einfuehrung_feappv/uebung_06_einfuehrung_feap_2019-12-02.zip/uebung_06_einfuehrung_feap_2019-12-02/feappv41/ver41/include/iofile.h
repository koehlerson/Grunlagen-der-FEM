
      integer         ior,iow
      common /iofile/ ior,iow

      logical         keepfl
      common /iofile/ keepfl

