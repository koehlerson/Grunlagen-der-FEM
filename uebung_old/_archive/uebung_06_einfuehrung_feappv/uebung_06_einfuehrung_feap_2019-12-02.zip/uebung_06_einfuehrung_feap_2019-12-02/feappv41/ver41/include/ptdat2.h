
      integer         idpl      ,ispl       ,ndplts,nsplts,ntstep
      common /ptdat2/ idpl(2,20),ispl(2,200),ndplts,nsplts,ntstep
