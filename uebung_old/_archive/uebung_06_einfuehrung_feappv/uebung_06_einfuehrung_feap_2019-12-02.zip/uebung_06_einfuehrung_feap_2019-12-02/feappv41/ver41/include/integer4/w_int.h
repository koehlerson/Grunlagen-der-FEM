
      integer        adr                        ! int4
      common /w_int/ adr(600)
