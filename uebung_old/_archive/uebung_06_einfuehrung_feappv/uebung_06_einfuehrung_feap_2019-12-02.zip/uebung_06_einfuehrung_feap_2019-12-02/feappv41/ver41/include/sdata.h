
      integer         ndf,ndm,nen1,nst,nneq
      common /sdata/  ndf,ndm,nen1,nst,nneq
