
      integer         inord    ,ipord        ,ipu
      common /pdata6/ inord(50),ipord(200,50),ipu(4,200)
