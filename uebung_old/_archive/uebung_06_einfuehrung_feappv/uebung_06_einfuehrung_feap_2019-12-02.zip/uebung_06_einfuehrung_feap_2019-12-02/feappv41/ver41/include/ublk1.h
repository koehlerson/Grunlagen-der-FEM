
      integer        ublkdat
      common /ublk1/ ublkdat(3,50)

      integer        ublknum
      common /ublk1/ ublknum
