
      logical         errck,eralloc
      common /errchk/ errck,eralloc
