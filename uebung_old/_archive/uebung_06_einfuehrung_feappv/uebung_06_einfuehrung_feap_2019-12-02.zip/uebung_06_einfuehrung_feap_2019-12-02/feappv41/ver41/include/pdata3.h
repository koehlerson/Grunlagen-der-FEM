
      integer         npstr
      logical               plfl,hide
      common /pdata3/ npstr,plfl,hide
