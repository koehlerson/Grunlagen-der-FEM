
      integer         totimem,totrmem,maxuse
      common /memuse/ totimem,totrmem,maxuse
