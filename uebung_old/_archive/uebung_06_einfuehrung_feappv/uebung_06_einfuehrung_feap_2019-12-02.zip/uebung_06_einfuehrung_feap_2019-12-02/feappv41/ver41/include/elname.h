
      character       umatn(15)*15
      common /elname/ umatn

