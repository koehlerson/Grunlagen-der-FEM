
      real*8          estore,edisip,einert
      common /elengy/ estore,edisip,einert
