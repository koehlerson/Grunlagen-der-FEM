
      real*8          b   ,c   ,aa   ,bb   ,cc   ,dd   ,ee
      common /shle16/ b(4),c(4),aa(4),bb(4),cc(4),dd(4),ee(4)
