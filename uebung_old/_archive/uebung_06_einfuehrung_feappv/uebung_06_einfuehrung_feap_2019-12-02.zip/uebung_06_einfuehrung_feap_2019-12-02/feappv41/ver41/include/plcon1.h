
      real*8          vlu   ,dx1
      integer                    nlabi
      logical                          vflg,tvc
      common /plcon1/ vlu(2),dx1,nlabi,vflg,tvc(9,9)
