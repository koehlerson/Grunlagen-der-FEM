
      real*8         trep,g
      common /elm2d/ trep,g(2,4)
