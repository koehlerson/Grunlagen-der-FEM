
      real*8          refx   ,tref
      integer                         lref,sref
      common /refnd/  refx(3),tref(3),lref,sref
