
      integer        iwindow,xpxl     ,wxy       ,wxi
      common /wdata/ iwindow,xpxl(2,3),wxy(2,2,3),wxi(2,3)

