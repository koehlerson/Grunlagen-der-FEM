
      integer         hlplev
      common /hlpdat/ hlplev
