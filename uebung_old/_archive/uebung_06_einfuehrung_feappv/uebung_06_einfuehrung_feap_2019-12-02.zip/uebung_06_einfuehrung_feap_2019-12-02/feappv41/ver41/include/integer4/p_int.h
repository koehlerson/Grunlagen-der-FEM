
      integer    fp(10)                   ! int4
