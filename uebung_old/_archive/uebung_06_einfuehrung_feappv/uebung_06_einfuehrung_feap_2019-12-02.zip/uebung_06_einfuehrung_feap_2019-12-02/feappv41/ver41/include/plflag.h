
      logical         bordfl,screfl,everon,blk,clip,lstrk,lfill
      common /plflag/ bordfl,screfl,everon,blk,clip,lstrk,lfill

      logical         plout
      common /plflag/ plout
