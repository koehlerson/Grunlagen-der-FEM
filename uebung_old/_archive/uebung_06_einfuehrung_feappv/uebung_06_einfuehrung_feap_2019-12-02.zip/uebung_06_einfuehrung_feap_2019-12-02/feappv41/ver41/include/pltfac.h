
      integer         nix,nxd,nxn,nne,nface
      common /pltfac/ nix,nxd,nxn,nne,nface
