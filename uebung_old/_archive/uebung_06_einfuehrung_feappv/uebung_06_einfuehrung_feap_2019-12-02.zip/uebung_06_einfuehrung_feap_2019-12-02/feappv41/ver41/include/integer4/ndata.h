
      integer         na,nal,nau                    ! int4
      common /ndata/  na,nal,nau

      integer         nc                            ! int4
      common /ndata/  nc

      integer         nl,nm                         ! int4
      common /ndata/  nl,nm

      integer         nxu,nul                       ! int4
      common /ndata/  nxu,nul

      integer         nv,nw,nx,nxl                  ! int4
      common /ndata/  nv,nw,nx,nxl
