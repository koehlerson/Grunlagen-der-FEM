
      real*8          hr
      integer                  mr
      common /comblk/ hr(1024),mr(1024)
