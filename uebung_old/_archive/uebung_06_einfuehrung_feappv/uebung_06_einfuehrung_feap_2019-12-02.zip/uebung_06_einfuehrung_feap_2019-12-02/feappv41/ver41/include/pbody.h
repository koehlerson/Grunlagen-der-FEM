
      integer         maplt
      common /pbody/  maplt
