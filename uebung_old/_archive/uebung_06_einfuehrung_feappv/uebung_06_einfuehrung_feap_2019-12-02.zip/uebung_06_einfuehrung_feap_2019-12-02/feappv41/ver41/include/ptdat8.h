
      real*8          upl
      integer                  iupl,       nuplts
      common /ptdat8/ upl(200),iupl(2,200),nuplts
