
      logical         coflg,ciflg,fileck
      common /codat/  coflg,ciflg,fileck
