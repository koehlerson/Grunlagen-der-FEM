
      real*8          augf
      common /augdat/ augf
