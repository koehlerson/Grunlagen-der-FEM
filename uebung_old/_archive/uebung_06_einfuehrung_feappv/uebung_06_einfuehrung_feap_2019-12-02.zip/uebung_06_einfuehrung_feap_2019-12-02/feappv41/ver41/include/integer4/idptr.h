
      integer        id31,idpt
      common /idptr/ id31,idpt(5)
