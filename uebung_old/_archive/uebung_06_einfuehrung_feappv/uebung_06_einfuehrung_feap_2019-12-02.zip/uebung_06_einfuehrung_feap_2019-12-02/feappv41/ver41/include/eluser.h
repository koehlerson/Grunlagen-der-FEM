
      real*8          ut
      common /eluser/ ut(1000)
