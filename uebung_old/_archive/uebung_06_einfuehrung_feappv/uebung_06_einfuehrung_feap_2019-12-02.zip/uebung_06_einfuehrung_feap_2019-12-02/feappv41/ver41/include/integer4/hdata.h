
      integer         nh1,nh2,nh3,nt1,nt2,nt3                     !int 4
      common /hdata/  nh1,nh2,nh3,nt1,nt2,nt3
