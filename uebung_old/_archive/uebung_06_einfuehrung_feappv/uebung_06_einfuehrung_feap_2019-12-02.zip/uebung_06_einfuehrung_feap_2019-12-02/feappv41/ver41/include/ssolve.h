
c----------Sparse Solver Common Blocks

      integer         esp,nsp,nspo,ipre
      logical                           lsolv1,lsolv2,domd
      common /ssolve/ esp,nsp,nspo,ipre,lsolv1,lsolv2,domd
