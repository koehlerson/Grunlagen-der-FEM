
      real*8          t1ref   ,t2ref
      common /sl3d02/ t1ref(3),t2ref(3)

      real*8          rmref     ,rmuref     ,rmoref
      common /sl3d02/ rmref(2,2),rmuref(2,2),rmoref(2,2)
