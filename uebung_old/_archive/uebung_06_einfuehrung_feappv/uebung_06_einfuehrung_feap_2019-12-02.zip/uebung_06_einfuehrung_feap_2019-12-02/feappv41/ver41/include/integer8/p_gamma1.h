
      integer*8   pr,pu                         ! int8
