
      real*8          rayla0,rayla1
      logical                        modfl
      common /modcom/ rayla0,rayla1, modfl
