
      real*8          xmin,   xmax
      integer                         nzm1,nzm2,nfac,nfmx,pdf
      common /pdata4/ xmin(3),xmax(3),nzm1,nzm2,nfac,nfmx,pdf(3)
