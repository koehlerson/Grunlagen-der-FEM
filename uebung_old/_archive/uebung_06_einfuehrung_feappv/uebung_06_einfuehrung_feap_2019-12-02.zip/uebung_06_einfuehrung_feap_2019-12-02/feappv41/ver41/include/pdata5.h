
      integer         exord,    epord
      common /pdata5/ exord(50),epord(50,50)
