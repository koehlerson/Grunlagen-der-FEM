
      real*8          bm
      integer                   ii1,ii2
      common /shld16/ bm(3,6,9),ii1,ii2
