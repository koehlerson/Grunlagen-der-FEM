
      real*8          tr     ,xr   ,trdet
      common /trdata/ tr(3,3),xr(3),trdet
