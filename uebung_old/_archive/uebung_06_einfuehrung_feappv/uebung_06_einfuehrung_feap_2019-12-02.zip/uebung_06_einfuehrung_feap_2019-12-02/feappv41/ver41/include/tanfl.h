
      logical         lafl,uafl,dbfl,ddfl
      common /tanfl/  lafl,uafl,dbfl,ddfl
