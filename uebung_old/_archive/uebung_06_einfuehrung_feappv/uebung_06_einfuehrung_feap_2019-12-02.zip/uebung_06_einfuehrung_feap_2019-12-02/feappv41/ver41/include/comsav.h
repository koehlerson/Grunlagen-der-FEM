
      character*128    fout_sav
      common /comsav1/ fout_sav

      integer          iow_sav
      logical                  prob_on
      common /comsav2/ iow_sav,prob_on
