
      real            tim0
      common /etime1/ tim0
