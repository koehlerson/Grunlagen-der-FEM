
      real*8          dpl    ,spl
      integer                          ntincr
      common /ptdat1/ dpl(20),spl(200),ntincr
