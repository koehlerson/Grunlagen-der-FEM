
      integer         nprob,nad,npd,irdef
      common /contrl/ nprob,nad,npd,irdef

      logical         bflg,cxifl,gapfl,incf,initf,intr,intx,nopart
      common /contrl/ bflg,cxifl,gapfl,incf,initf,intr,intx,nopart

      logical         nocount,tfl,hisfl
      common /contrl/ nocount,tfl,hisfl

      character       fnamr*132, fnamp*128, flog*128
      common /conchr/ fnamr    , fnamp    , flog

