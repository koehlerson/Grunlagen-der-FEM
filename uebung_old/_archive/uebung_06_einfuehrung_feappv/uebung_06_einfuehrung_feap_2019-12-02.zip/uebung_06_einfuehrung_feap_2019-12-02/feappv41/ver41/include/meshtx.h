
      character       tx(8)*15
      common /meshtx/ tx
