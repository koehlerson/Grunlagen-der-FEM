
      real*8          lpl
      integer                  ilpl,       nlplts
      common /ptdat7/ lpl(200),ilpl(2,200),nlplts
