
      integer     pr,pu                         ! int4
