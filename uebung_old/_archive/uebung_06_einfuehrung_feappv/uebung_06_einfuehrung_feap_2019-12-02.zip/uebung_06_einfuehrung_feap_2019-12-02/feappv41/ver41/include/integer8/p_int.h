
      integer*8  fp(10)                   ! int8
