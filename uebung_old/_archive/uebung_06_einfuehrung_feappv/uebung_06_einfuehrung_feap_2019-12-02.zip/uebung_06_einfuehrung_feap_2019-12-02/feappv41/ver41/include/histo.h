
      integer         nl1,nl2,nt1,nt2,nhv,nhi,nht,nhf,nhl,nhj,nhk
      common /histo/  nl1,nl2,nt1,nt2,nhv,nhi,nht,nhf,nhl,nhj,nhk
