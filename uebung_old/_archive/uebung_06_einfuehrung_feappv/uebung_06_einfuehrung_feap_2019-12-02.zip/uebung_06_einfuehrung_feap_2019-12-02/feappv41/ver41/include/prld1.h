
      real*8         prldv    ,propo
      common /prld1/ prldv(50),propo
