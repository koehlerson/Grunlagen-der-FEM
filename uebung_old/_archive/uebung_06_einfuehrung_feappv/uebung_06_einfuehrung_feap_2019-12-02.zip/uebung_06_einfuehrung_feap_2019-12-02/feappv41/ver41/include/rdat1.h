
      real*8          rnorm,rn0,tdiff
      common /rdat1/  rnorm,rn0,tdiff
