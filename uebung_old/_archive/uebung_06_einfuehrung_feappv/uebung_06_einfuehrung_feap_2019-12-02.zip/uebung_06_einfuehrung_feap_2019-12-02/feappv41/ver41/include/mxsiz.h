
      logical         lkflg
      integer               mxpro,mxneq,nren
      common /mxsiz/  lkflg,mxpro,mxneq,nren
