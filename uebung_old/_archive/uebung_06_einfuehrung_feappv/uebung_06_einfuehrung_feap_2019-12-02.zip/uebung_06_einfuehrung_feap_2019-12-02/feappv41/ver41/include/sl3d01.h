
      real*8          t1   ,t2   ,rn   ,t1u   ,t2u   ,e12 
      common /sl3d01/ t1(3),t2(3),rn(3),t1u(3),t2u(3),e12(3)

      real*8          rk     ,rm     ,ra     ,rmu     ,rau
      common /sl3d01/ rk(2,2),rm(2,2),ra(2,2),rmu(2,2),rau(2,2)
