
      integer*8        pl(10)                                   ! int8
