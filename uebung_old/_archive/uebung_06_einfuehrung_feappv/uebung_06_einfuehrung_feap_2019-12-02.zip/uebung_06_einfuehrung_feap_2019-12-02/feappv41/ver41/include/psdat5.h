
      integer         xold,yold,dold,lwold
      common /psdat5/ xold,yold,dold,lwold
