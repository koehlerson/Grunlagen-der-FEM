
      real*8          vvv         ,www    ,vvsave
      common /conval/ vvv(26,0:36),www(26),vvsave(26,0:36)
