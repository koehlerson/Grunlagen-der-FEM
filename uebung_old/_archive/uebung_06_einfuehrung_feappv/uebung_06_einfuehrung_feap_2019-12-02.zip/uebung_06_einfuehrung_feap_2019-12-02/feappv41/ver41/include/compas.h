
      integer         ittyp,nnm,nnc,nnr,maxbl,iccom
      common /compas/ ittyp,nnm,nnc,nnr,maxbl,iccom

      logical         compfl,compms,cadamp,castif,camass,causer
      common /compas/ compfl,compms,cadamp,castif,camass,causer
