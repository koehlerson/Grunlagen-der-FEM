
      character*4     o,head
      common /bdata/  o,head(20)
