
      integer         ndebug
      logical                debug
      common /debugs/ ndebug,debug
