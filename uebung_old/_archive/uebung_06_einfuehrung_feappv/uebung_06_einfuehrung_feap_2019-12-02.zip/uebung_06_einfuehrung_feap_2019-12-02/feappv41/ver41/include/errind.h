
      real*8          eerror,eproj,efem
      common /errind/ eerror,eproj,efem

      integer         ertyp
      common /errind/ ertyp
