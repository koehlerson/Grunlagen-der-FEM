
      character       clin*3,cvar*4,colv*2,oclin*3,ocvar*4,ocolv*2
      common /psdat2/ clin,  cvar,  colv  ,oclin  ,ocvar  ,ocolv
