
      real*8         rangmn,rangmx
      logical                      rangfl
      common/prange/ rangmn,rangmx,rangfl
