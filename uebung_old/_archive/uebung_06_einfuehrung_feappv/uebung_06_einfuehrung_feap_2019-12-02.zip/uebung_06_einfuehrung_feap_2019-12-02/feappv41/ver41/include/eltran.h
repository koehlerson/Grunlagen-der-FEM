
      real*8          bpr   ,ctan
      common /eltran/ bpr(3),ctan(3)
