
      integer         numint
      logical                dynflg
      common /dyndat/ numint,dynflg
