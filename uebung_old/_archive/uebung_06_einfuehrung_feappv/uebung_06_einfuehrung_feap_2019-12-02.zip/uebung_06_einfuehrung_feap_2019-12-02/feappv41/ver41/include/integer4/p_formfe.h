
      integer     pnu,pnb,pna,pnl                 ! int4
