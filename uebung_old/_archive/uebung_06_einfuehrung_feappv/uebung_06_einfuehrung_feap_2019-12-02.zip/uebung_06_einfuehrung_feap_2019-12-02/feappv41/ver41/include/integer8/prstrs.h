
      integer*8       nph,ner                       ! int8
      real*8                  erav
      common /prstrs/ nph,ner,erav
