
      real*8          xref   ,xcur
      common /elcoor/ xref(3),xcur(3)
