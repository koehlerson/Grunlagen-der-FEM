
      integer         nnodmax,numcels
      logical                         optflg,optmsh
      common /compac/ nnodmax,numcels,optflg,optmsh

      logical         kbycol,kdiag,kall
      common /compac/ kbycol,kdiag,kall

      logical         mbycol,mdiag,mall
      common /compac/ mbycol,mdiag,mall

      logical         cbycol,cdiag,call
      common /compac/ cbycol,cdiag,call

      logical         ubycol,udiag,uall,ulfl
      common /compac/ ubycol,udiag,uall,ulfl
