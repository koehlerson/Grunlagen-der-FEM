
      real*8          sg     ,sgt      ,xsjt
      logical                                qdflg
      common /shlc16/ sg(3,9),sgt(2,11),xsjt,qdflg
