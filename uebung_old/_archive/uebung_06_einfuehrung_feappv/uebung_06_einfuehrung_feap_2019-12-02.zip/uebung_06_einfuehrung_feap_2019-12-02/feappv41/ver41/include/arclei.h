
      integer         kflag,ite,ndis,ndamp,nodis,nddis
      common /arclei/ kflag,ite,ndis,ndamp,nodis,nddis
