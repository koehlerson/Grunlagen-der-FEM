
      integer         nhmax,nh3max
      logical                      hflgu,h3flgu,ndflg
      common /hdatam/ nhmax,nh3max,hflgu,h3flgu,ndflg

      logical         pltmfl
      common /hdatam/ pltmfl

