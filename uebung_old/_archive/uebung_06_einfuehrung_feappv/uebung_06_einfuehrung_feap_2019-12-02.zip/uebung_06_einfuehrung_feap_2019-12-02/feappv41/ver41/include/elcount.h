
      integer           nomats      ,unmats
      common /elcount/  nomats(2,10),unmats(2,10)
