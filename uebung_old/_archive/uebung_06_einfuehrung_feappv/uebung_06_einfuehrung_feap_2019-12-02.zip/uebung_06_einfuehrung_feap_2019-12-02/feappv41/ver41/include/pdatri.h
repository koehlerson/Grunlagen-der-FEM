
      real*8          xmx,xmn,ymx,ymn
      common /pdatri/ xmx,xmn,ymx,ymn
