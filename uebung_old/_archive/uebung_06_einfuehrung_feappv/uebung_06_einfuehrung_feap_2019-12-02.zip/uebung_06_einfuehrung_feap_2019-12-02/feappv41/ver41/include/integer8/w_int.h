
      integer*8      adr                        ! int8
      common /w_int/ adr(600)
