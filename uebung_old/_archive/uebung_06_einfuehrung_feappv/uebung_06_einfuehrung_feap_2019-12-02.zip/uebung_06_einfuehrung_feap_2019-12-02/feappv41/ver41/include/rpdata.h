
      real*8          rmn,rmx
      common /rpdata/ rmn,rmx
