
      real*8          vmin   ,vmax
      common /pdata0/ vmin(3),vmax(3)
