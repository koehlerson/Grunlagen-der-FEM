
      logical         arcf,refl
      common /arclel/ arcf,refl
