
      real*8          rpl
      integer                  irpl,       nrplts
      common /ptdat5/ rpl(200),irpl(2,200),nrplts
