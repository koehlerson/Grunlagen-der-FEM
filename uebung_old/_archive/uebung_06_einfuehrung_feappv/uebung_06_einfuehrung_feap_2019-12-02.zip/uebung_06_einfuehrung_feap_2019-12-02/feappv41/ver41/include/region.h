
      integer         nreg,mxreg
      common /region/ nreg,mxreg
