
      integer         imtyp,md,mv,mf,mq
      common /evdata/ imtyp,md,mv,mf,mq
