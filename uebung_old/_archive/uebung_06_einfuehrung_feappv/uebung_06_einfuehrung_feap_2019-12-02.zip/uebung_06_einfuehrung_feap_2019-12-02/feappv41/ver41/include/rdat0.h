
      real*8          enzer
      integer               nmeth,nmethp
      common /rdat0/  enzer,nmeth,nmethp(4)
