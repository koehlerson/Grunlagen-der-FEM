
      real*4          xx,   yy
      common /x11f/   xx(8),yy(8)
