
      real*8          gtan
      common /gltran/ gtan(3)
