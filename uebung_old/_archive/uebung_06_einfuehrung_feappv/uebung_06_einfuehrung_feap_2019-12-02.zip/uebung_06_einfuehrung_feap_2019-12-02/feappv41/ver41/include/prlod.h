
      real*8          prop,ap
      integer                       iexp    ,ik    ,npld
      common /prlod/  prop,ap(7,50),iexp(50),ik(50),npld
