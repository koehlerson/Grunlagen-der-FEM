
      real*8          cmin   ,cmax
      real*4                          xc   ,yc
      integer         ienter,iexit
      logical                      fwin,clchk,fwoff,psoff
      common /plclip/ cmin(3),cmax(3),xc(4),yc(4)
      common /plclip/ ienter,iexit,fwin,clchk,fwoff,psoff
