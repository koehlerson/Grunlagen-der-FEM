
      character       fname*12
      common /psdat4/ fname
