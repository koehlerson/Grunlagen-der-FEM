
      real*8          theta
      integer                  nrk,nrc,nrm,nrt,noi,nt,nrkn,nrcn,nrmn
      common /ddata/  theta(4),nrk,nrc,nrm,nrt,noi,nt,nrkn,nrcn,nrmn

      integer         nrvn
      common /ddata/  nrvn

