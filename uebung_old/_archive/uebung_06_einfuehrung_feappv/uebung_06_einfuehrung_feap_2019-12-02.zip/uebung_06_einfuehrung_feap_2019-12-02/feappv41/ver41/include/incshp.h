
      real*8          shpi,     ui
      common /incshp/ shpi(3,3),ui(5,2)
