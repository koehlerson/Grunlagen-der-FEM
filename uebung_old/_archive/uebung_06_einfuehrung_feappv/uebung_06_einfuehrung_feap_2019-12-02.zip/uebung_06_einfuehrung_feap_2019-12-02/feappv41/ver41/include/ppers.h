
      real*8         e   ,eold   ,tg   ,vold   ,q     ,xlbda     ,enorm
      integer        kpers
      common /ppers/ e(3),eold(3),tg(3),vold(3),q(3,3),xlbda(3,3),enorm,
     &               kpers
