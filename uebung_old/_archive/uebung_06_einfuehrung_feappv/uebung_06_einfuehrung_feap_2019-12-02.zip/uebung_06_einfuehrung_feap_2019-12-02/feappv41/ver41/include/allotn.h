
      character*5     nlist     ,dict
      common /allotn/ nlist(600),dict(200)
