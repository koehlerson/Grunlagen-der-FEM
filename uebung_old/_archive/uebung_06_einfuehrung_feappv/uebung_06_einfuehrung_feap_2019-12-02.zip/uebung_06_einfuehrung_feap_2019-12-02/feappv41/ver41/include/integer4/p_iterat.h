
      integer    pu,prsd                        ! int4
