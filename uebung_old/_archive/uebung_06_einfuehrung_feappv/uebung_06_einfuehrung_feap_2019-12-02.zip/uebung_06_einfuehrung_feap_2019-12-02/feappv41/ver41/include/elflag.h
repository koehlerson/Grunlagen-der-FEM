
      integer          elstart    ,ellast
      common /elflag/  elstart(80),ellast(80)
