
      real*8         cc1,cc2,cc3
      common /tdatb/ cc1,cc2,cc3
