
      logical         hdcpy,hdlogo,psfram
      common /pdatps/ hdcpy,hdlogo,psfram
