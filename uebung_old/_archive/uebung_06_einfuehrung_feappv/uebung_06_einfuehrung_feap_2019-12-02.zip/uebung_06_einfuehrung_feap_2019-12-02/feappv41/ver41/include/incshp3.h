
      real*8           ui
      common /incshp3/ ui(3,3,2)
