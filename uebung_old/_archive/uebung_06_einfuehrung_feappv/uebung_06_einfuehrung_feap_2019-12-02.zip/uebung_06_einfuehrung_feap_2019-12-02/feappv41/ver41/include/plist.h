
      integer         niols,   iolist
      common /plist/  niols(3),iolist(100,3)
