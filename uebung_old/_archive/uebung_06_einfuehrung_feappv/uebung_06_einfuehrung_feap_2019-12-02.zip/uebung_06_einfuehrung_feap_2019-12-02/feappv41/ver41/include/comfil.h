
      character*128   finp,fout,fres,fsav,fplt,fincld
      common /comfil/ finp,fout,fres,fsav,fplt,fincld(10)

      character*256   record
      common /comrec/ record

      integer         findex
      common /comint/ findex

