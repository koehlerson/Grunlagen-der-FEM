
      integer         neqs
      common /eqsym/  neqs

