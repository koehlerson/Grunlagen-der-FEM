
      real*8             macd
      integer                 maci
      common /pconstant/ macd,maci

