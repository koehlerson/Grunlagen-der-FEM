
      integer         icf,isf,isfile    ,irecrd
      common /ioincl/ icf,isf,isfile(10),irecrd(10)
