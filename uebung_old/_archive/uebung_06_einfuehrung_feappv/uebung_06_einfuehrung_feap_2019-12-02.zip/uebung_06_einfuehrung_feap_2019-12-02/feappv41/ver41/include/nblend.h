
      integer         nursn,nursd,nurfc,nurbd,mxnlr
      common /nblend/ nursn,nursd,nurfc,nurbd,mxnlr

      integer         nurdm
      common /nblend/ nurdm
