
      character       versn*17
      common /vdata/  versn(2)
