
      real*8          grefx   ,gtref   ,gray   ,gfac
      integer                                            gref
      common /refng/  grefx(3),gtref(3),gray(2),gfac(14),gref
