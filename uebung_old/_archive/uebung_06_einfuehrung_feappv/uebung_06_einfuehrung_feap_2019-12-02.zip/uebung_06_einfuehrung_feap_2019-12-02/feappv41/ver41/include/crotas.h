
      integer         ndof
      logical                 fsetr,frotas
      common /crotas/ ndof(9),fsetr,frotas
