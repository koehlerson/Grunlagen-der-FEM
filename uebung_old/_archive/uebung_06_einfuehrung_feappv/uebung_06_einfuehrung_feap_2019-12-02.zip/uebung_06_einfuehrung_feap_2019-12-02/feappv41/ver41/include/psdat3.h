
      real*4          x11,      y11
      common /psdatz/ x11(200), y11(200)
