
      real*8          elplt
      common /elpdat/ elplt(3)
