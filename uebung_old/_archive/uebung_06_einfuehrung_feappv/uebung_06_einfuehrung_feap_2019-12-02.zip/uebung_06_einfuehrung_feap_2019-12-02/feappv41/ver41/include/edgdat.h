
      integer         neang,nebcs,nedis,nefrc,nepro,nebas,ncurv
      common /edgdat/ neang,nebcs,nedis,nefrc,nepro,nebas,ncurv

      integer         nespi
      common /edgdat/ nespi

      logical         eanfl,ebcfl,edifl,efcfl,eprfl,ebsfl,curfl
      common /edgdat/ eanfl,ebcfl,edifl,efcfl,eprfl,ebsfl,curfl

      logical         espfl
      common /edgdat/ espfl
