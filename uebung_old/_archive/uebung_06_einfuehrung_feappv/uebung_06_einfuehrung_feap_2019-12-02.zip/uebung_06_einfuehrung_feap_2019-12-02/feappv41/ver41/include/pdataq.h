
      integer         npf,ixy
      common /pdataq/ npf,ixy(2,31)
