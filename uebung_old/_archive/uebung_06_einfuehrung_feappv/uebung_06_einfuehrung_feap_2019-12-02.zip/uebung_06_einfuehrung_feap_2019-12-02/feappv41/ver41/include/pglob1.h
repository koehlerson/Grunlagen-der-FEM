
      integer         g2type,gdtype,gtdof
      common /pglob1/ g2type,gdtype,gtdof
