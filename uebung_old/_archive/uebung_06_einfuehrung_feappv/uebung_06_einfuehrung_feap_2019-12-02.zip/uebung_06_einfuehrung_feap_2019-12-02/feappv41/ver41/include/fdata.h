
      logical         fl,    pfr
      common /fdata/  fl(12),pfr
