
      integer         lfile
      logical               lread,lsave,eofile
      common /iosave/ lfile,lread,lsave,eofile
