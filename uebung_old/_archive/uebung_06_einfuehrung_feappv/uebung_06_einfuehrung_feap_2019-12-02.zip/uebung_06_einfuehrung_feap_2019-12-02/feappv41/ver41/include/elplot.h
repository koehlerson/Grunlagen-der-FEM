
      real*8          tt
      common /elplot/ tt(200)
