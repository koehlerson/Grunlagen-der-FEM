
      integer         ncapt
      character              caption*15
      common /plcapt/ ncapt, caption
