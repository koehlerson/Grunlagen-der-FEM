
      real*8          sigt,   sigb
      common /sstr16/ sigt(6),sigb(6)
