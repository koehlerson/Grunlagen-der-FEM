
      integer           zero, one, two
      common /constant/ zero, one, two
