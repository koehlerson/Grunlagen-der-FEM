
      integer         iclink
      common /linka/  iclink
