
      integer*8   pnu,pnb,pna,pnl               ! int8
