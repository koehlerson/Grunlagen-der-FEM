
      real*8          x0
      common /cdat2/  x0(3)
