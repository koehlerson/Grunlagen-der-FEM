
      integer         maxm,incred
      common /psize/  maxm,incred
