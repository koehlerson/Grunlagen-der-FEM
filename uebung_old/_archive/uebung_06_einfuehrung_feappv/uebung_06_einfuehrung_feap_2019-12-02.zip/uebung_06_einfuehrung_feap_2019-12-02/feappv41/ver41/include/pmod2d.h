
      integer         stype,etype,dtype
      logical                           plasfl,viscfl,hflag,gflag
      common /pmod2d/ stype,etype,dtype,plasfl,viscfl,hflag,gflag
