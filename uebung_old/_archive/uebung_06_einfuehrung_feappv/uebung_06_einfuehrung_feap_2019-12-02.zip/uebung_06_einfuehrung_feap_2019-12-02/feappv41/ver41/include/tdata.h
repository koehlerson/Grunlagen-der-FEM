
      real*8          ttim,dt,c1,c2,c3,c4,c5, chi
      common /tdata/  ttim,dt,c1,c2,c3,c4,c5, chi
