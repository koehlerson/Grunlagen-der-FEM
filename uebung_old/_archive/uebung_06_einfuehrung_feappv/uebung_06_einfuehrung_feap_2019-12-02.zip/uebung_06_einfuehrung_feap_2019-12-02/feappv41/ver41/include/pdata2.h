
      integer         iclear,idev,idx,idy,ipb,ifrm,icolr,ilno
      common /pdata2/ iclear,idev,idx,idy,ipb,ifrm,icolr,ilno(2)
