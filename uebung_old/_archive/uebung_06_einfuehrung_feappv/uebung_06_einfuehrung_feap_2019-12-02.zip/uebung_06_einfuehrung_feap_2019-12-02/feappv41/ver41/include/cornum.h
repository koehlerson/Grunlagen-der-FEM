
      integer         nsurf,nbouf,ndisf,nforf,nangf,nintf,nside,nprof,
     &                nfol
      common /cornum/ nsurf,nbouf,ndisf,nforf,nangf,nintf,nside,nprof,
     &                nfol
