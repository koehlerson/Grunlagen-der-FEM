
      real*8           defa   ,strs   ,siglr    ,epslr        ,sl
      common  /bm2com/ defa(3,2),strs(3,2),siglr(50),epslr(50),sl(2,6)
