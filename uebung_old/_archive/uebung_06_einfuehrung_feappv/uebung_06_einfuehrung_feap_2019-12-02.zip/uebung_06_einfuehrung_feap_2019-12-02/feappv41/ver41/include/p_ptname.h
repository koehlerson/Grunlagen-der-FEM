      character         partname(250)*15
      common /c_ptname/ partname

      integer           last_elm,ipart,ptelm
      common /i_ptname/ last_elm,ipart,ptelm(3,250)
