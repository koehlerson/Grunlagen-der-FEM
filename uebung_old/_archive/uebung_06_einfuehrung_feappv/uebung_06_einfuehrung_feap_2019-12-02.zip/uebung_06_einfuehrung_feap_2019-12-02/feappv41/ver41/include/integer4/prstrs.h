
      integer         nph,ner                       ! int4
      real*8                  erav
      common /prstrs/ nph,ner,erav
