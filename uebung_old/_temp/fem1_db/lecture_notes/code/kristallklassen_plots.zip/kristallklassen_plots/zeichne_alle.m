cd cubic_shuvalov
Ag
Cu
Fe
Na
NaCl
cd ..
cd hexagonal_shuvalov
Be
Co
Re
Zn
cd ..
cd monoclinic_Simmons
Aegirite
cd ..
cd rhombic_Simmons
Acenaphthene
Uranium_richtig
cd ..
cd tetragonal_Royer
BaTiO3
TeO2
TiO2
cd ..
cd trigonal_Royer
Al2O3
LiNbO3
Te
cd ..
close all
clear all
disp('Batch Verarbeitung abgeschlossen')
